package core;

import java.util.Iterator;
import java.util.TreeSet;

public class Treeset_Example {

	public static void main(String args[]){  
		//Creating and adding elements  
		TreeSet<String> set=new TreeSet<String>();  
		set.add("shubham");  
		set.add("rhoit");  
		set.add("Ravi");  
		set.add("akash");  
		//traversing elements  
		Iterator<String> itr=set.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
		}  
}

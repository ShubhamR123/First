package core;

public class Operators {

	public static void main(String[] args) {
		
		//Arithmetic operators -> + , - , / , % , ++ , --    Arithmetic operators cannot work with booleans % operators can work on float & double
		int a = 4;
		
		int b = 6 * a;   // Assignment operators  ->  = , + = , * =    
		
		int c  = 6 % a; // Modulo operator
		
		int d = 9;
		
		d += 3;
		System.out.println(d);
		
		System.out.println(6==6);  // Comparison Operator   => = =, > = , < =
		System.out.println(64 < 6);
		
		
		System.out.println(64>4 && 64>5); // Logical operators
		System.out.println(64>5 || 64>98);
		
		
		System.out.println(2 & 3);
	}
}

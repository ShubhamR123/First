package core;
import java.util.*;  

import java.util.ArrayList;

public class ArrayList_Example {
	
	public static void main(String args[])
	 {  
		  ArrayList<String> list=new ArrayList<String>();          //Creating ArrayList    
		      list.add("shubham");                             //Adding object in ArrayList    
		      list.add("rohit");    
		      list.add("kartik");    
		      list.add("akash");    
		      Iterator itr=list.iterator();//getting the Iterator  
		      
		      while(itr.hasNext())
		      {//check if iterator has the elements  
		    	  
		       System.out.println(itr.next());//printing the element and move to next  
		       System.out.println("...........");
		     //Traversing list through for-each loop  
		       for(String name:list)    
		         System.out.println(name);    
		      }  
		 }  
}

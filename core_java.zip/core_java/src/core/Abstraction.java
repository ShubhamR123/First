package core;

//Abstract class having constructor, data member and methods


abstract class Home{  
	
	Home()  // using constructor
	   
	   {
		   System.out.println("Home is created");
		   
		  }  
	   abstract void run();  
	   void place()
	   {
		   System.out.println("Nandanvan");
		   }  
	 }  
	//Creating a Child class which inherits Abstract class  
	 class Honda extends Home{  
	 void run()
	 {
		 System.out.println("running safely..");
		 }  
	 }  
	 
	 interface car
	 {                              // using interface
		 void akash();  
		 void rohit();  
		 void nisha();  
		 void d(); 
		 
		 }  
		   
		 abstract class BMW implements car
		 {  
		 public void nisha()
		 {
			 System.out.println("I am nisha");
			 }  
		 }  
		   
		 class GT extends BMW{  
		 public void akash()
		 {
			 System.out.println("I am akash");
			 }  
		 public void rohit() 
		 {
			 System.out.println("I am rohit");
			 }  
		 public void d()
		 {
			 System.out.println("I am d");
			 }  
		 }  
	//Creating a Test class which calls abstract and non-abstract methods  
	 class Abstraction
	 {  
	 public static void main(String args[])
	 {  
		 car a=new GT();  
		 a.akash();  
		 a.rohit();  
		 a.nisha();  
		 a.d();  
		 
		 Home obj = new Honda();  
	  obj.run();  
	  obj.place();  
	 }  
	}  

package core;

public class Unchecked_Exception {

	 public static void main(String args[])  
	   {  
		 
	    int number = 35;  
	    int value = 0;  
	    int result = number/value; 
	                                   //Give Unchecked Exception here. show ArithmeticException  
	System.out.println(result);  
	
	   }  
}


package core;

public class Constructor {

	int id;
	String name;
	int age;
	
	Constructor(int i, String n) //creating two arg constructor  

	{
		id = i; 
		name = n;
	}
	Constructor(int i,String n,int a)      //creating three arg constructor  
	{
		 id = i;  
		    name = n;  
		    age=a;  
	}
	void show ()
	{
		System.out.println(id+" "+name+" "+age);
	} 


	public static void main(String[] args) {
		
		Constructor ref = new Constructor(1,"shubham");
		Constructor ref1 = new Constructor(1,"shubham",5);

		ref.show();
		ref1.show();
	}
}
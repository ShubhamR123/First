package core;

public class StaticVariable {

	int empid;
	char name;
	static String dept = "Hey";
	
	static void change ()
	{
		dept = "Hello";
		
	}
	
	StaticVariable (int e, char n)
	{
		empid = e;
		name = n;
		
	}
	
	void display()
	{
		System.out.println("Empid: "+empid+"Ename:"+name+"Dept:"+dept);
	}
	
	
	static String sum = "sum";
	static String diff = "Difference";
	
	public static void main(String[] args) {
		
		StaticVariable.change();
		StaticVariable sv = new StaticVariable(1, 'S');
		StaticVariable sv1 = new StaticVariable(2, 'R');
		sv.display();
		sv1.display();
		
		
		int a = 10;
		int b = 20;
		int c = a + b;
		int d = a - b;
		
		System.out.println(sum+c);
		System.out.println(diff+d);
	}
}

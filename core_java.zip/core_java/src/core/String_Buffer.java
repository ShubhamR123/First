package core;

public class String_Buffer {

	public static void main(String args[])
	{  
		StringBuffer sb=new StringBuffer("Hello "); 
		
		sb.append("Java");          //now original string is changed  
		
		System.out.println(sb);         //prints Hello Java 
		
		
		
		
		StringBuffer sb1=new StringBuffer("Hello "); 

		sb1.insert(1," Java1");//insert() Method

		System.out.println(sb1);
		
		
		
		
		StringBuffer sb2=new StringBuffer("Hello "); 

		sb2.replace(1,3,"Java");  //Replace Method

		System.out.println(sb2);//prints HJavalo  
		
		

		
		StringBuffer sb3=new StringBuffer("Hello"); 
		sb3.delete(1,3);                              // delete Method
		System.out.println(sb3); 

		
		
		StringBuffer sb4=new StringBuffer("Hello");  
		sb4.reverse();                                    // Reverse Method
		System.out.println(sb4);//prints olleH  
		}  
}

package core;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Checked_Exception {

	public static void main(String args[]) throws IOException 
	{  
        FileInputStream file_data = null;  
        file_data = new FileInputStream("/Users/apple/Documents/workspace-spring-tool-suite-4-4.15.3.RELEASE/core_java/c class.txt");  
        int m;  
        while(( m = file_data.read() ) != -1)
        {  
            System.out.print((char)m);  
        }  
        file_data.close();  
    }  
}

package core;


class Student1
{
	private int rollno;
	private String name;       // generate setters and getters
	public int getRollno()
	{
		return rollno;
	}
	public void setRollno(int rollno) 
	{
		this.rollno = rollno;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
}
public class Encapsulation {

	public static void main(String[] args) {
		
		Student1 s = new Student1();
		s.setRollno(2);
		s.setName("shubham");
		
		System.out.println(s.getRollno());
		System.out.println(s.getName());
	}
}

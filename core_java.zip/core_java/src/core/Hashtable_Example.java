package core;

import java.util.Hashtable;
import java.util.Map.Entry;

public class Hashtable_Example {

	 public static void main(String args[]){  
		  Hashtable<Integer,String> hm=new Hashtable<Integer,String>();  
		  
		  hm.put(100,"Akash");  
		  hm.put(102,"Ravindra");  
		  hm.put(101,"Rachelwar");  
		  hm.put(103,"Rahul");  
		  
		  for(Entry<Integer, String> m:hm.entrySet()){  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  }  
		 }  
}

package core;

class parent
{
	void Showroom()
	{
		System.out.println("Audi A6");
	}
}

class child extends parent  // Single Inheritance Example

{
	void theater()
	{
		System.out.println("PVR");
	}
}

class bigbull extends child    // Multilevel Inheritance Example

{
	void weep()
	{
		System.out.println("weeping");
	}
}
public class Inheritance {
	
	public static void main(String[] args) {
		
		bigbull c = new bigbull();
		c.Showroom();
		c.theater();
		c.weep();
	
	}
}

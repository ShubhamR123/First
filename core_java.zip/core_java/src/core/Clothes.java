package core;

import java.util.Scanner;

class Shopping
{
    String selection;
    int quantity;
    int id_Number;
    char product_Name;
    double total_Price;
    double discount;
    double n;
    double total;
    public void setDetails()
    {
         
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Selection(Jeans,Tshirt,Shirt)");
         selection= scanner.next();
        
        System.out.println("Enter Quantity");
        quantity = scanner.nextInt();
        
        System.out.println(" Enter ID_number");
        id_Number = scanner.nextInt();
        
        System.out.println("Enter Product name");
        product_Name = scanner.next().charAt(0);
        
        System.out.println("Enter Discount");
        discount = scanner.nextDouble();
        
                
    }
    
   
    public void getSelection()
    {
        System.out.println("select the cloths");
        total_Price = (500 * quantity);
        System.out.println("All product total price"+total_Price);
    
    }
    
    public void getDiscount()
    {
                n =   discount;

        total = ((500*quantity)-(n*500*quantity)/100);
        System.out.println("amount after discount"+total);
    }
    
}
public class Clothes {
public static void main(String[] args) {
	 Shopping ob = new Shopping();
     ob.setDetails();
     ob.getSelection();
     ob.getDiscount();

}
}

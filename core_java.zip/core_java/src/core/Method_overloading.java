package core;


public class Method_overloading {

	void sum (int i)
	{
		System.out.println("First Function" +i);
	}
	
	void sum (int i, int j)
	{
		System.out.println("Second Function" +(i + j));
	}
	
	void sum (int i, int j, int k)
	{
		System.out.println("Third Function" +(i+j+k));
	}
	
	  
		static int add(int a,int b)  // changing no. of arguments
		{
			return a+b;
			
		}  
		static int add(int a,int b,int c)
		{
			return a+b+c;
			
		}  
		
		static int add1(int c, int d) // changing data type of arguments
		{
			return c+d;
			
		}  
		static double add1(double c, double d)
		{
			return c+d;
			
		}  
	public static void main(String[] args) {
		
		Method_overloading obj = new Method_overloading();
		obj.sum(10);
		
		obj.sum(5, 9);
		
		obj.sum(4, 10, 54);
		
		System.out.println(Method_overloading.add(7,8));  
		System.out.println(Method_overloading.add(10,15,53));  
	}
}

package core;

class Circle
{
    double length;
    double breadth;
    double radius;
    public void setArea(double l, double b, double r)
    {
        length = l;
        breadth = b;
        radius = r;
        
    }
    public void getArea()
    {
        double ar = length * breadth;
        System.out.println("Enter the area of rectangle"+ar);
    }
    public void getRectangle()
    {
        double pr = 2*(length+breadth);
       	System.out.println("Enter the peri of rectangle"+pr);
    }
    public void getAreaC()
    {
        double ac = 3.14*radius*radius;
       	System.out.println("Enter the area of circle"+ac);
    }
    public void getCircumference()
    {
        double cc = 2*3.14*radius;
	System.out.println("Enter the cir of circle"+cc);
    }
}
public class Circle5 {

	public static void main(String[] args) {
		Circle ob = new Circle();
	      ob.setArea(10, 20, 30);
	      ob.getArea();
	      ob.getAreaC();
	      ob.getCircumference();
	      ob.getRectangle();
	}
}

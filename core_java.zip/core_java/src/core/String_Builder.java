package core;

public class String_Builder {

	public static void main(String args[])
	{  
		StringBuilder sb=new StringBuilder("Hello "); 
		
		sb.append("Java");          //now original string is changed  
		
		System.out.println(sb);         //prints Hello Java 
		
		
		
		
		StringBuilder sb1=new StringBuilder("Hello "); 

		sb1.insert(1," Java1");//insert() Method

		System.out.println(sb1);
		
		
		
		
		StringBuilder sb2=new StringBuilder("Hello "); 

		sb2.replace(1,3,"Java");  //Replace Method

		System.out.println(sb2);//prints HJavalo  
		
		

		
		StringBuilder sb3=new StringBuilder("Hello"); 
		sb3.delete(1,3);                              // delete Method
		System.out.println(sb3); 

		
		
		StringBuilder sb4=new StringBuilder("Hello");  
		sb4.reverse();                                    // Reverse Method
		System.out.println(sb4);//prints olleH  
		}  
}

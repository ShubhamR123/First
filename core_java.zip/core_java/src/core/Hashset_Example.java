package core;

import java.util.Iterator;
import java.util.HashSet;

public class Hashset_Example {

	public static void main(String args[]){  
		HashSet<String> set=new HashSet<String>();  
		set.add("Ravi");  
		set.add("devil");  
		set.add("sunita");  
		set.add("Ajay");  
		Iterator<String> itr=set.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
		}  
}

package core;


class Student
{  
     int id;  
     int rollno;  
     String name;  

Student(int id,int rollno,String name)  //using this keyword
{  
    this.id=id; 
    this.rollno=rollno;  
    this.name=name;  
 
} 

   void display()
   {
	   System.out.println(id+" "+rollno+" "+name);
    }  
}  

public class This_Keyword {

	public static void main(String args[]){  
		Student s1=new Student(1,1234,"ankit");  
		Student s2=new Student(2,3456,"sumit");  
		s1.display();  
		s2.display();  
	}
}

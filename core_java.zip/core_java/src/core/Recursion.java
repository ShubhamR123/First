package core;

public class Recursion {

	static int count=0;
	
	static void print()
	{  
	count++;  
	if(count<=5)
	{  
	System.out.println("hello "+count);  //finite times
	print(); 
	
	}  
	
	}  
	public static void main(String[] args) {  
	print();  
	}  
}

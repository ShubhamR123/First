package core;

import core.BARODA;
import core.BOI;
import core.CANARA;
import core.Test;

class Demo
{
	public void show()
	{
		System.out.println("Hello world");
	}
}

class Test extends Demo   //Creating child classes.  

{
	public void show()
	{
		super.show();
		System.out.println("Bike is running safely");
	}
	
	
}
class BOI extends Demo
{  
int getRateOfInterest()
{
	return 8;
} 

}  
  
class BARODA extends Demo
{  
int getRateOfInterest()
{
	return 7;
	}  
}  
class CANARA extends Demo
{  
int getRateOfInterest()
{
	return 9;
	}  
} 

public class Method_overriding {
	public static void main(String[] args) {
		BOI s=new BOI();  
		BARODA i=new BARODA();  
		CANARA a=new CANARA();  
		System.out.println("BOI Rate of interest: "+s.getRateOfInterest());  
		System.out.println("BARODA Rate of Interest: "+i.getRateOfInterest());  
		System.out.println("CANARA Rate of Interest: "+a.getRateOfInterest());  
		Test obj = new Test();
		obj.show();
	}
}

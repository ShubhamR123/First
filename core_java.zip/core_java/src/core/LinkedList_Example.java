package core;
import java.util.*;  

import java.util.LinkedList;


public class LinkedList_Example {

	 public static void main(String args[]){  
		  
		  LinkedList<String> al=new LinkedList<String>();  
		  al.add("sunita");  
		  al.add("Vijay");  
		  al.add("Ravindra");  
		  al.add("shubham");  
//		  
//		  Iterator<String> itr=al.iterator();  
//		  while(itr.hasNext()){  
//		   System.out.println(itr.next());  
		   
		  //Traversing the list of elements in reverse order  
          Iterator i=al.descendingIterator();  
          while(i.hasNext())  
          {  
              System.out.println(i.next());  
          }  
		   
		   
		   
		  }  
		 }  


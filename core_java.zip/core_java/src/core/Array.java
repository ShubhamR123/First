package core;

public class Array {

	public static void main(String args[]){  
		int a[]=new int[5];          //declaration and instantiation  
		a[0]=1;                   //initialization  
		a[1]=2;  
		a[2]=3;  
		a[3]=4;  
		a[4]=5;  
		                            //traversing array  
		for(int i=0;i<a.length;i++) //length is the property of array  
		System.out.println(a[i]); 
		System.out.println("............");
		
		
		int b[]={2,3,4,5};//declaration, instantiation and initialization  
		//printing array  
		for(int i=0;i<b.length;i++)//length is the property of array  
		System.out.println(b[i]);  
		
		
		System.out.println("............");

		int arr[]={2,3,4,5};  
		                        // array using for-each loop  
		for(int i:arr)  
		System.out.println(i);  
}
}

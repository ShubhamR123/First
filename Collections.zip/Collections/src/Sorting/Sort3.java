package Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Sort3 {

	public static void main(String args[]){  
		  
		ArrayList list=new ArrayList();  
		
		list.add(Integer.valueOf(201));  
		list.add(Integer.valueOf(101)); 
		
		list.add(230);   
		  
		Collections.sort(list);  
		  
		Iterator itr=list.iterator(); 
		
		while(itr.hasNext())
		{  
		System.out.println(itr.next());  
		 }  
		}  
}

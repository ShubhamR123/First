package Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


//sort string objects in reverse order

public class Sort2 {

	public static void main(String args[]){  
		  
		ArrayList<String> list=new ArrayList<String>();  
		          list.add("Virat");    
		          list.add("Saurabh");    
		          list.add("Mukul");    
		          list.add("Tabish");   
		          
		        Collections.sort(list,Collections.reverseOrder());  
		        
		        
		        Iterator i=list.iterator();  
		        while(i.hasNext())  
		        {  
		            System.out.println(i.next());  
		        }  
		}  
}

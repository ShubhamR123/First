package LinkedHashSet;

import java.util.LinkedHashSet;

public class Set3 {

	public static void main(String[] args) {
		
		LinkedHashSet<String> list = new LinkedHashSet<String>();  
		  
		 
		list.add("Java");  
		list.add("T");  
		list.add("Point");  
		list.add("Good");  
		list.add("Website");  
		  
		// displaying all the elements on the console  
		System.out.println("The hash set is: " + list);  
		
		
		//the element "Good" is present, therefore, the method remove()  
		// returns true  

		System.out.println(list.remove("Good")); 
		
		System.out.println("After removing the element: " + list);  
		
		
		//  the element "For" is not present, therefore, the method remove()  
		// returns false  
		System.out.println(list.remove("For"));  

	}
}

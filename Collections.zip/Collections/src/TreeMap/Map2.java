package TreeMap;

import java.util.Map;
import java.util.TreeMap;

public class Map2 {

	
	public static void main(String args[]) {  
		
	    TreeMap<Integer,String> map=new TreeMap<Integer,String>();   
	    
	      map.put(100,"Devil");    
	      map.put(102,"Ravan");    
	      map.put(101,"Ghost");    
	      map.put(103,"Evil"); 
	      
	      System.out.println("Before  remove() method"); 
	      
	      for(Map.Entry m:map.entrySet())  
	      {  
	          System.out.println(m.getKey()+" "+m.getValue());      
	      }  
	      map.remove(102);  
	      
	      System.out.println("After  remove() method");  
	      
	      for(Map.Entry m:map.entrySet())  
	      {  
	          System.out.println(m.getKey()+" "+m.getValue());      
	      }  
	      
	      }  
}

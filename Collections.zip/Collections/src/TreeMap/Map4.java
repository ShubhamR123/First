package TreeMap;
//sort map
import java.util.SortedMap;
import java.util.TreeMap;

public class Map4 {

	 public static void main(String args[]){  
		   SortedMap<Integer,String> map=new TreeMap<Integer,String>();  
		   
		      map.put(100,"uzzair");    
		      map.put(102,"pankaj");    
		      map.put(101,"shil");    
		      map.put(103,"pandit"); 
		      
		      System.out.println("headMap: "+map.headMap(102));  
		      System.out.println("tailMap: "+map.tailMap(102));  
		      System.out.println("subMap: "+map.subMap(100, 102));    
		 }  
}

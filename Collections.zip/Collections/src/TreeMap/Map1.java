package TreeMap;

import java.util.Map;
import java.util.TreeMap;

public class Map1 {

	 public static void main(String args[]){  
		   Map<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(100,"amit");    
		      map.put(102,"rogit");    
		      map.put(101,"parag");    
		      map.put(103,"vikas");    
		        
		      for(Map.Entry m:map.entrySet())
		      {    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }    
		 }  
}

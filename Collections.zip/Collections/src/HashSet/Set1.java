package HashSet;

import java.util.HashSet;
import java.util.Iterator;

public class Set1 {

	public static void main(String args[]){  
		
		                                       //Creating HashSet and adding elements  
		   HashSet<String> set=new HashSet();  
		   
		           set.add("Hey");    
		           set.add("Hi");    
		           set.add("Hello");   
		           set.add("Bro");  
		           set.add("Dude");  
		           
		           Iterator<String> i=set.iterator();  
		           
		           while(i.hasNext())  
		        	   
		           {  
		        	   
		           System.out.println(i.next());  
		           
		           }  
           }
}
package HashSet;

import java.util.HashSet;

class Seller {  
int id;  
String name;
String author;
String publisher;  
int quantity;  
 Seller(int id, String name, String author, String publisher, int quantity) {  
    this.id = id;  
    this.name = name;  
    this.author = author;  
    this.publisher = publisher;  
    this.quantity = quantity;  
}  
}  
public class Set5 {

	public static void main(String[] args) {
		
		HashSet<Seller> set=new HashSet<Seller>();  
		
	    //Creating seller
		
		Seller b1=new Seller(101," C","shubham ","rachelwar",8);  
		Seller b2=new Seller(102,"java","rohit"," bawankule",4);  
		Seller b3=new Seller(103,"c++ ","kartik","irpate",6);  
		
	    //Adding seller to HashSet  
		
	    set.add(b1);  
	    set.add(b2);  
	    set.add(b3);  
	    
	    for(Seller b:set){  
	    System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);  
	    }  
	}
}

package HashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

//HashSet from another Collection
public class Set4 {

	 public static void main(String args[]){  
		   ArrayList<String> list=new ArrayList<String>();  
		           list.add("Hey");  
		           list.add("Java");  
		           list.add("Bro");  
		             
		           HashSet<String> set=new HashSet(list);  
		           set.add("Good bye"); 
		           
		           Iterator<String> itr = set.iterator();
		           
		           while(itr.hasNext())
		           {
		        	   System.out.println(itr.next());
		           }
		           
		 }  
}

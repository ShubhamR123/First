package HashSet;

import java.util.HashSet;
import java.util.Iterator;

//ignoring duplicate elements

public class Set2 {

public static void main(String[] args) {
	
	  HashSet<String> set=new HashSet<String>();  
	  set.add("Rohit");  
	  set.add("karik");  
	  set.add("Rohit");  //HashSet doesn't allow duplicate elements.
	  set.add("shubham");  
	  
	  Iterator<String> itr = set.iterator();
	  
	  while(itr.hasNext())
	  {
		  System.out.println(itr.next());
	  }
}
}

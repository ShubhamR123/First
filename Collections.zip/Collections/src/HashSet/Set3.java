package HashSet;

import java.util.HashSet;


//remove elements

public class Set3 {

	public static void main(String[] args) {
		
		HashSet<String> set=new HashSet<String>();  
        set.add("lip");  
        set.add("shruti");  
        set.add("nisha");  
        set.add("priyanka");  
        System.out.println(" initial list of elements: "+set); 
        
        //Removing specific element from HashSet  

        set.remove("Ravi");  
        System.out.println("remove method: "+set);  
        
        HashSet<String> set1=new HashSet<String>();  
        set1.add("dipak");  
        set1.add("Gaurav");  
        set.addAll(set1);  
        System.out.println("Updated List: "+set);  
        
        //Removing all the new elements from HashSet  
        set.removeAll(set1);  
        System.out.println("removeAll method: "+set);  
        
      //Removing all the elements available in the set  
        set.clear();  
        System.out.println(" clear() method: "+set);  
	}
}

package HashMap;

import java.util.HashMap;

public class Map3 {

	 public static void main(String args[])
	 {  
		    HashMap<Integer,String> map=new HashMap<Integer,String>();  
		    
		      map.put(1,"shubham");    
		      map.put(2,"kartik");    
		      map.put(3,"Rahul");  
		      map.put(4, "rohit");  
		      
		    System.out.println("Initial list of elements: "+map);  
		                                                       //key-based removal  
		    map.remove(1);  
		    System.out.println("Updated list of elements: "+map);  
		    
		    //value-based removal  
		    
		    map.remove(2);  
		    System.out.println("Updated list of elements: "+map);  
		    
		    //key-value pair based removal  
		    
		    map.remove(3, "Rahul");  
		    System.out.println("Updated list of elements: "+map);  
		    
		   }      
}

package ArrayList;

import java.util.ArrayList;
import java.util.Iterator;

//to traverse ArrayList elements using the Iterator interface.

public class List2 {
	
 public static void main(String[] args) {
	 
	ArrayList<String> list = new ArrayList<>();  // create arrayList
	list.add("shubham");
	list.add("kartik");
	list.add("rohit");
	list.add("akash");
	
	Iterator itr = list.iterator();  //getting the Iterator  
	
	while(itr.hasNext()) //check if iterator has the elements  
	{
		System.out.println(itr.next());
	}
}
}

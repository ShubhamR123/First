package ArrayList;

import java.util.ArrayList;
import java.util.Iterator;

//User-defined class objects in Java ArrayList

class Student
{
	int rollno;
	String name;
	String college;
	
	Student(int rollno, String name, String college)
	{
		this.rollno = rollno;    // using this keyword
		this.name = name;
		this.college = college;
         
	}
}
public class List5 {
	
 public static void main(String[] args) {
	
	 Student s1 = new Student(1, "shubham", "raisoni");    //Creating user-defined class objects  
	 Student s2 = new Student(2, "kartik", "ycc");
	 Student s3 = new Student(3, "rohit", "kdk");
	 
	 
	 ArrayList<Student> list  = new ArrayList<>();    //creating arrayList  

	 list.add(s1);
	 list.add(s2);
	 list.add(s3);
	 
	 list.remove(s1);               //Removing specific element from arrayList  

	 
	 Iterator itr = list.iterator();
	 
	 while(itr.hasNext())
	 {
		 Student s =(Student)itr.next();    //traversing elements of ArrayList object  

		 System.out.println(s.rollno+" "+ s.name +" "+ s.college);
	 }
	 
}
}

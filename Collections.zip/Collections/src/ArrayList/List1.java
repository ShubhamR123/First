package ArrayList;

import java.util.ArrayList;

public class List1 {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<>();
		list.add("shubham");
		list.add("kartik");
		list.add("rohit");
		list.add("akash");
		
		System.out.println(list);
	}
}

package ArrayList;

import java.util.ArrayList;
import java.util.ListIterator;

//to traverse the ArrayList elements through other ways

public class List4 {

	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<>();  // create arrayList
		list.add("shubham");
		list.add("kartik");
		list.add("rohit");
		list.add("akash");
		
        System.out.println("Traversing list through List Iterator:");  
		
        ListIterator<String> list1=list.listIterator(list.size());  
		
		while(list1.hasPrevious()) //iterates in reverse order  
		{
			String str = list1.previous();
			System.out.println(str);
		};
		
        System.out.println("Traversing list through For Loop:");  
        
        for(int i=0; i<list.size();i++)
        {
        	System.out.println(list.get(i));
        }

        
        System.out.println("Traversing list through For-each Method():");  
        
        list.forEach(a->{
        	
        	System.out.println(a);
        });

	}
}

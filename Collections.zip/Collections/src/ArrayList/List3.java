package ArrayList;

import java.util.ArrayList;

//to traverse the ArrayList elements using the for-each loop

public class List3 {
 
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<>();  // create arrayList
		list.add("shubham");
		list.add("kartik");
		list.add("rohit");
		list.add("akash");
		
		for(String name:list)   // using the for-each loop
		{
			System.out.println(name);
		}
	}
}

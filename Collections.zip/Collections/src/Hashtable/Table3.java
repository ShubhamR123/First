package Hashtable;

import java.util.Hashtable;


//getOrDefault()
public class Table3 {

	public static void main(String args[]){  
	    Hashtable<Integer,String> map=new Hashtable<Integer,String>(); 
	    
	     map.put(100,"shahid");    
	     map.put(102,"Ranveer");   
	     map.put(101,"Imraan");    
	     map.put(103,"Ranbir");    
	     
	     System.out.println(map.getOrDefault(102, "Not Found"));  
	     
	     System.out.println(map.getOrDefault(105, "Not Found"));  
	 }  
}

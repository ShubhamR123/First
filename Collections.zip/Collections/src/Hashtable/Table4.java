package Hashtable;

import java.util.Hashtable;

//putIfAbsent()
public class Table4 {

	public static void main(String[] args) {
		
		 Hashtable<Integer,String> map=new Hashtable<Integer,String>();   
		 
	     map.put(100,"Amir");    
	     map.put(102,"siddhart");   
	     map.put(101,"salman");    
	     map.put(103,"vivek");    
	     System.out.println("Initial Map: "+map);  
	     
	     map.putIfAbsent(104,"Gaurav");  
	     System.out.println("Updated Map: "+map);  
	}
}

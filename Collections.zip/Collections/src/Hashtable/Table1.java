package Hashtable;

import java.util.Hashtable;
import java.util.Map;

public class Table1 {

	 public static void main(String args[]){  
		 
		  Hashtable<Integer,String> table=new Hashtable<Integer,String>();  
		  
		  table.put(1,"vaibhav");  
		  table.put(2,"umesh");  
		  table.put(3,"shivam");  
		  table.put(4,"Rahul");  
		  
		  for(Map.Entry m:table.entrySet())
		  {  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  }  
		 }  
}

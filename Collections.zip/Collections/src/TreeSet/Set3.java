package TreeSet;

import java.util.TreeSet;

// to retrieve and remove the highest and lowest Value.

public class Set3 {

	public static void main(String args[]){   
		
		 TreeSet<Integer> set=new TreeSet<Integer>();   
		 
		         set.add(14);    
		         set.add(26);    
		         set.add(12);    
		         set.add(130);    
		         
		         System.out.println("Lowest Value: "+set.pollFirst());
		         
		         System.out.println("Highest Value: "+set.pollLast());    
		 }    
}

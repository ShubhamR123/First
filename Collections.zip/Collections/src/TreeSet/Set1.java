package TreeSet;

import java.util.Iterator;
import java.util.TreeSet;

public class Set1 {

	 public static void main(String args[]){  
		 
		  //Creating and adding elements  
		 
		  TreeSet<String> list=new TreeSet<String>();  
		  
		  list.add("shubham");  
		  list.add("Vijay");  
		  list.add("rahul");  
		  list.add("shivam");  
		  
		  Iterator<String> itr=list.iterator();  
		  
		  while(itr.hasNext())
		  {  
		   System.out.println(itr.next());  
		  }  
		 }  
}

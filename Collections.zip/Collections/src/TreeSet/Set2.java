package TreeSet;

import java.util.Iterator;
import java.util.TreeSet;

//traversing elements in descending order.

public class Set2 {

	 public static void main(String args[]){ 
		 
		 TreeSet<String> set=new TreeSet<String>();  
		 
		         set.add("rahul");  
		         set.add("gulshan");  
		         set.add("sweekar"); 
		         set.add("manish");
		         set.add("praik");
		         
		         System.out.println(" Iterator in descending order");  
		         
		         Iterator itr = set.descendingIterator();  
		         
		         while(itr.hasNext())  
		         {  
		             System.out.println(itr.next());  
		         }  
		           
		 }  
}

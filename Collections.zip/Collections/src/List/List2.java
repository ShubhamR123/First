package List;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class List2 {

	public static void main(String args[]){  
		
		 List<String> city = new ArrayList<>();    
		 city.add("Nagpur");    
		 city.add("Pune");    
		 city.add("Mumbai");    
		 city.add("Delhi");    
		 
		 //Converting ArrayList to Array 
		 
		 String[] array = city.toArray(new String[city.size()]);  
		 
		 System.out.println("Printing Array: "+Arrays.toString(array)); 
		 
		 System.out.println("Printing List: "+city);  
		}  
}

package List;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class List3 {
	
public static void main(String[] args) {
	
	List<String> list=new ArrayList<String>();    
	list.add("rohit");    
	list.add("sarang");    
	list.add("parag");    
	list.add(1,"abhishek");   
    
    ListIterator<String> itr=list.listIterator(); 
    
    System.out.println(" elements in forward direction");    
    while(itr.hasNext()){    
          
    System.out.println("index:"+itr.nextIndex()+" value:"+itr.next());    
    }    
    System.out.println(" elements in backward direction");  
    
    while(itr.hasPrevious())
    {    
      
    System.out.println("index:"+itr.previousIndex()+" value:"+itr.previous());    
    }    
}
}

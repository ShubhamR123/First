package ArrayDeque;

import java.util.ArrayDeque;
import java.util.Deque;

class Seller {    
int id;    
String name,author,publisher;    
int quantity;  

public Seller(int id, String name, String author, String publisher, int quantity)
{    
    this.id = id;    
    this.name = name;    
    this.author = author;    
    this.publisher = publisher;    
    this.quantity = quantity;    
}    

}    
public class Deque3 {

	public static void main(String[] args) {    
		
	    Deque<Seller> set=new ArrayDeque<Seller>();   
	    
	    //Creating Seller    
	    Seller b1=new Seller(101,"C","Rohit","bawankule",4);    
	    Seller b2=new Seller(102,"Java","Shubham","Rachelwar",5);    
	    Seller b3=new Seller(103,"Python","Kartik","Irpate",6);    
	    
	    //Adding Seller to Deque   
	    
	    set.add(b1);    
	    set.add(b2);    
	    set.add(b3);    
	    
	    //Traversing ArrayDeque  
	    
	    for(Seller b:set)
	    {    
	    System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);    
	    }    
	}    
}

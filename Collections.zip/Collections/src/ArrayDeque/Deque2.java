package ArrayDeque;

import java.util.ArrayDeque;
import java.util.Deque;

//offerFirst() and pollLast()

public class Deque2 {

	public static void main(String[] args) {  
	    Deque<String> deque=new ArrayDeque<String>();  
	    
	    deque.offer("karan");  
	    deque.offer("golu");  
	    deque.add("siddhant");  
	    deque.offerFirst("abhishek");  
	    
	    System.out.println("After offerFirst Traversal...");  
	    
	    for(String s:deque)
	    {  
	        System.out.println(s);  
	    }  
	    
	    deque.pollLast();  
	    System.out.println("After pollLast() Traversal...");  
	    
	    for(String s:deque)
	    {  
	        System.out.println(s);  
	    }  
	}  
}

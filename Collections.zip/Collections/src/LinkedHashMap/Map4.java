package LinkedHashMap;

import java.awt.print.Book;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;


class Seller {  
int id;  
String name;
String author;
String publisher;  
int quantity;  
 Seller(int id, String name, String author, String publisher, int quantity) {  
    this.id = id;  
    this.name = name;  
    this.author = author;  
    this.publisher = publisher;  
    this.quantity = quantity;  
}  
}  
public class Map4 {

public static void main(String[] args) {
		
    Map<Integer,Seller> map=new LinkedHashMap<Integer,Seller>();    
		
	    //Creating seller
		
    Seller b1=new Seller(101," C","shubham ","rachelwar",8);    
    Seller b2=new Seller(102,"java","rohit"," bawankule",4);    
    Seller b3=new Seller(103,"c++ ","kartik","irpate",6);    
    //Adding Books to map   
    map.put(2,b2);  
    map.put(1,b1);  
    map.put(3,b3);  
	    for(Map.Entry<Integer, Seller> entry:map.entrySet()){    
	        int key=entry.getKey();  
	        Seller b=entry.getValue();  
	        System.out.println(key+" Details:");  
	        System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);   
	    }    
}
}

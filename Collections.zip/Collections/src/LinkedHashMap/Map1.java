package LinkedHashMap;

import java.util.LinkedHashMap;
import java.util.Map;

public class Map1 {

	public static void main(String args[]){  
		   
		  LinkedHashMap<Integer,String> map=new LinkedHashMap<Integer,String>();  
		  
		  map.put(100,"abhi");  
		  map.put(101,"poonam");  
		  map.put(102,"lalit");  
		  
		for(Map.Entry m:map.entrySet())
		{  
		   System.out.println(m.getKey()+" "+m.getValue());  
		  }  
		 }  
}

package LinkedHashMap;

import java.util.LinkedHashMap;
import java.util.Map;

public class Map3 {

	
	public static void main(String args[]) {  
		
	    Map<Integer,String> map=new LinkedHashMap<Integer,String>();   
	    
	     map.put(4,"priyanka");    
	     map.put(5,"nisha");    
	     map.put(6,"shruti");    
	     
	     System.out.println("Before invoking remove() method: "+map); 
	     
	    map.remove(4);  
	    
	    System.out.println("After invoking remove() method: "+map);    
	   }      
}

package LinkedList;

import java.util.Iterator;
import java.util.LinkedList;

// reverse a list of elements
public class List3 {

	public static void main(String args[]){  
		  
		  LinkedList<String> list=new LinkedList<String>();  
		                  list.add("shubham");  
		                  list.add("kartik");  
		                  list.add("akash");  
		           
		           //Traversing the list of elements in reverse order  
		           
		           Iterator i=list.descendingIterator();  
		           while(i.hasNext())  
		           {  
		               System.out.println(i.next());  
		           }  
		             
		 }  
}

package LinkedList;


//different ways to remove an element.

import java.util.LinkedList;

public class List2 {

	public static void main(String[] args) {
		
		LinkedList<String> list=new LinkedList<String>();  
		list.add("shubham");  
		list.add("kartik");  
		list.add("rohit");  
		list.add("pankaj");  
		list.add("vikky");  
		list.add("lip");  
		list.add("akash");  
		list.add("Gaurav");  
		
        System.out.println("Initial list of elements: "+list);  
        
        //Removing specific element from arrayList  

        list.remove("Vijay");  
        System.out.println("remove(object) method: "+list);  
        
        //Removing element on the basis of specific position  

        list.remove(0);  
        System.out.println("After invoking remove(index) method: "+list);   
        
        
        LinkedList<String> list1=new LinkedList<String>();  
        list1.add("akshay");  
        list1.add("lalit");  
        
        
   // Adding new elements to arrayList  
        
        list.addAll(list1);  
        System.out.println("Updated list : "+list);   

        //Removing all the new elements from arrayList  
        
        list.removeAll(list1);  
        System.out.println("After invoking removeAll() method: "+list); 
        
        
   //Removing first element from the list  
        
        list.removeFirst();  
        System.out.println("After invoking removeFirst() method: "+list);  
        
        
    //Removing first element from the list  
        
        list.removeLast();  
        System.out.println("After invoking removeLast() method: "+list); 
        
        
        //Removing all the elements available in the list       
        
        list.clear();  
        System.out.println("After invoking clear() method: "+list);   

	}
}

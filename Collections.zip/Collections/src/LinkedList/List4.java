package LinkedList;

import java.util.LinkedList;
import java.util.List;

class Student {  
int id;  
String name;

public  Student(int id, String name)
{
	this.id = id;  
    this.name = name;  

}
}
public class List4 {

	
	public static void main(String[] args) {
		
	    List<Student> list=new LinkedList<Student>(); 
	    
	    Student s1 = new Student(1, "java");
	    Student s2 = new Student(2, "c++");
	    
	    list.add(s1);  
	    list.add(s2);  
	    
	    for(Student b:list){  
	        System.out.println(b.id+" "+b.name);
	}
}
}
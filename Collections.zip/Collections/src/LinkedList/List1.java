package LinkedList;

import java.util.LinkedList;

//different ways to add elements.

public class List1 {

	public static void main(String[] args) {
		
		LinkedList<String> list = new LinkedList<>();
		list.add("shubham");
		list.add("kartik");
		list.add("rohit");
		list.add("akash");
		System.out.println("initial list"+list);
		
		list.add("lalit");
		System.out.println("add new name"+list);
		
		
		LinkedList<String> list1 = new LinkedList<>();
		list1.add("shruti");
		list1.add("priyanka");
		list1.add("nisha");
		
		System.out.println("create new list"+list1);
		
		list.addAll(list1);   //Adding second list elements to the first list  

		System.out.println(list);
		
        //Adding an element at the first position  

		list.addFirst("amit");
		System.out.println(list);
		
		
        //Adding an element at the last position  

		list.addLast("swapnil");
		System.out.println(list);

	}
}

package Java_7_and_8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class JavaSort {

	public static void main(String[] args) {
		
		List<String> Location = new ArrayList<String>();  //list of string object
		Location.add("Nagpur");
		Location.add("Pune");
		Location.add("Mumbai");
		
		JavaSort javaSort = new JavaSort();  // object of the class javaSort
		javaSort.Java7(Location);   //create a method Java7
		System.out.println(Location);
		Location.add("delhi");
		
		javaSort.Java8(Location);
		System.out.println(Location);

		
	}

	private void Java8(List<String> location) {
		// TODO Auto-generated method stub
		Collections.sort(location, (A1, A2) -> A1.compareTo(A2));  //java 7 this is equivalent to the same one line
	}

	private void Java7(List<String> location) { 
		// TODO Auto-generated method stub
		
		Collections.sort(location, new Comparator<String>() {

			@Override
			public int compare(String A1, String A2) {  // two argument it is used to compare
				// TODO Auto-generated method stub
				return A1.compareTo(A2);
			}
		});
	}
}

package Java_7_and_8;

class A
{
	int speed;
	void showSpeed()
	{
		System.out.println("A");
	}
}

class B extends A
{
	String color;
	void topSpeed()
	{
		System.out.println("B");
	}
}


public class SimpleTesting extends B,A{
	
public static void main(String[] args) {

	System.out.println("A");
	System.out.println("B");

}
}

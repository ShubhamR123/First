package lambda;

public interface LengthInter {

	int getlength(String str);
}

package lambda;

public class MyInterImpl implements MyInter {

	@Override
	public void Hello() {
		// TODO Auto-generated method stub
		System.out.println("hello Mac");
	}

}

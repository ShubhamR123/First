package lambda;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Main {
	
public static void main(String args[])
{
	
	System.out.println("My System start");
	
	System.out.println("................");

	//create separate class and implements this interface
	
	MyInter myInter = new MyInterImpl();
	myInter.Hello();
	
	System.out.println("................");

	
	//anonymous class
	
	MyInter i = new MyInter() {
		
		@Override
		public void Hello() {
			// TODO Auto-generated method stub
			System.out.println("this is my first anonymous class");
		}
	};
	i.Hello();
	System.out.println("................");

	
	MyInter i2 = new MyInter() {
		
		@Override
		public void Hello() {
			// TODO Auto-generated method stub
			System.out.println("this is my second anonymous class");

		}
	};
 i2.Hello();
	System.out.println("................");

 
 //using our interface with the help of lambda expression
 
 //without using curle bracket
 
 MyInter j = () -> System.out.println("This is first time i am using lambda expression");
 j.Hello();
	System.out.println("................");

 //using curle bracket
 
 MyInter j2 = () ->{
	 System.out.println("This is second time i am using lambda expression");
 };
 j2.Hello();
	System.out.println("................");

 //using type function
 
 SumInter sumInter =(int a, int b)->{
	 
	 return a+b;
 };
 System.out.println(sumInter.sum(4, 6));
 
 System.out.println(sumInter.sum(6, 8));
	System.out.println("................");

 //without using type function
 
 SumInter  sumInter1 = (a, b) -> a+b;
 
 System.out.println(sumInter1.sum(5, 6));
 
 System.out.println(sumInter1.sum(10, 8));
 
	System.out.println("................");

 // String length
 
 LengthInter lengthInter =(str -> str.length());
 System.out.println("length of the String is "+lengthInter.getlength("Shubham rachelwar"));
	System.out.println("................");

 
 //Functional Interface types ---- 4 types
 
 // 1) Predicate-- boolean result
 
 Predicate<String> checkLength = str -> str.length()>5;
 
 //checking if length of string >5 --- true -- else -- false
 
 System.out.println(checkLength.test("checklength")); //true
 
 System.out.println(checkLength.test("abcd"));// false

	System.out.println("................");

 
 // 2) Consumer-- modifies-- data--- no output
 
 class Demo
 {
	 private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
 }
 
 Demo p = new Demo();
 Consumer<Demo> setName =t->t.setName("Hello World");
 setName.accept(p);
 System.out.println(p.getName());
	System.out.println("................");

 
 // 3)  Function both input and output
 
 Function<Integer, String> getInt =t->t*5 + " data multiple by 5 ";
 System.out.println(getInt.apply(4));
 
	System.out.println("................");

 // 4) Supplier-- only output
 
 Supplier<Double> getrandomDouble=()-> Math.random();
 System.out.println(getrandomDouble.get());
 
}
}

package lambda;

@FunctionalInterface
public interface MyInter {

	public abstract void Hello();
}

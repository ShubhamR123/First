package Final_Finally_Finalize;

public class Final {

	final int age = 18;   //declaring final variable
	void display()
	{
		age = 20;   // reassigning value age     // gives compile time error
	}
	public static void main(String[] args) {
		
		Final f = new Final();
		f.display();
	}
}

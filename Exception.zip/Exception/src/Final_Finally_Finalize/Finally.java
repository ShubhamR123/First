package Final_Finally_Finalize;

public class Finally {

	public static void main(String[] args) {
		
		try
		{
			int data = 50/0;
			System.out.println(data);
		}
//		catch (ArithmeticException e) 
//		{
//			System.out.println("Arithmetic");
//		}
		finally
		{
			
		}
		System.out.println("rest");
	}
}

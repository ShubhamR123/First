package Final_Finally_Finalize;

public class Finalize {

	public static void main(String[] args) {
		
		Finalize f = new Finalize();
		
		System.out.println("Hashcode "+ f.hashCode());
		
		f = null;
		
		System.gc();
		System.out.println("Garbage collection");
		
		
	}
	protected void finalize()
	
	{
		System.out.println("Finalize method");
	}
}

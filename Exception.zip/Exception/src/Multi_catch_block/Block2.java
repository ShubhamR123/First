package Multi_catch_block;

public class Block2 {

	public static void main(String[] args) {
		
		try
		{
		int a []= new int [10];
		
		System.out.println(a[8]);  //print 0
		
		System.out.println(a[11]);  // print ArrayIndexOutOfBoundsException
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic"+e);

		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("ArrayIndex"+e);

		}
		catch(Exception e)
		{
			System.out.println("Exception"+e);

		}
		System.out.println("rest");

	}
}

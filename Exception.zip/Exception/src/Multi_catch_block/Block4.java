package Multi_catch_block;

//we generate NullPointerException, 
//but didn't provide the corresponding exception type. 
//In such case, the catch block containing 
//the parent exception class Exception will invoked.



public class Block4 {

	public static void main(String[] args) {
		
		 try{    
			 
//				String name = "shubham";
//				System.out.println(name.length());    //show length 
				
             String name1 = null;
 			System.out.println(name1.length());   // show NullPointerException bcoz name is null
            }   
//			catch(NullPointerException e)
//			{
//				System.out.println(e);
//			}
		 catch(ArithmeticException e)
			{
				System.out.println("Arithmetic"+e);

			}  
            catch(ArrayIndexOutOfBoundsException e)
    		{
    			System.out.println("ArrayIndex"+e);

    		} 
			catch(Exception e)  
			{
				System.out.println("Exception");

			}
            
            System.out.println("rest of the code");    
 }  
}

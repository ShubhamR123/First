package Multi_catch_block;


//try block contains two exceptions. But at a time only one exception occurs 
//and its corresponding catch block is executed.


public class Block3 {

	public static void main(String[] args) {
		
		try
		{
			int a [] = new int [5];
			
			
			//a[5] = 4/0;        // print Arithmetic Exception
			
			
			a[6] = 4/3;     // print ArrayIndexOutOfBoundsException
			
			System.out.println(a[7]);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic"+e);

		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("ArrayIndex"+e);

		}
		catch(Exception e)
		{
			System.out.println("Exception"+e);

		}
		System.out.println("rest");

	}
}

package Multi_catch_block;

public class Block1 {
	
public static void main(String[] args) {
	
	try
	{
		int a [] = new int [7];

		a[7] = 50/2;
	}
	catch(ArithmeticException e)
	{
		System.out.println("Arithmetic"+e);
	}
	
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println("ArrayIndex"+e);
	}
	catch(Exception e)  //parent
	{
		System.out.println("Exception"+e);
	}
	
	System.out.println("rest");
}
	
}

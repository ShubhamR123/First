package Multi_catch_block;


// to handle the exception without maintaining the order of exceptions
//(i.e. from most specific to most general).


public class Block5 {

	public static void main(String[] args) {
		
          try
          {
        	  int a [] = new int[6];
        	  
        	  a[6] = 50/0;
        	  
          }
          catch(Exception e)
          {
				System.out.println("Exception");

          }
          catch( ArithmeticException | ArrayIndexOutOfBoundsException e)
          {
  			System.out.println("Arithmetic"+e);
          }
          
         
	}
}

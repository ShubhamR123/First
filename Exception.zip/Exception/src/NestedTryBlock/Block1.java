package NestedTryBlock;

public class Block1 {

	public static void main(String[] args) {
		
		        //outer try block
		try
		{  
			//inner try block 1
			
	       try {     
		       System.out.println("print");
		       int a = 50/0;
		}
		     catch(ArithmeticException e)   // catch block of inner try block 1  
		{
			System.out.println("Arithmetic"+e);
		}
		
	    //inner try block 2  

			try
			{
				int b [] = new int[4];
				
			    //assigning the value out of array bounds  

				b[5] = 5;
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println("Array index"+e);
			}
			
			System.out.println("other statement");
				
			}
		
		  //catch block of outer try block  

	 catch(Exception e)  
	  {  
	    System.out.println("handled the exception (outer catch)");  
	  }    
	    
	  System.out.println("normal flow..");    
	 }    
	}  
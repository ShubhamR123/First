package Throws;
import java.io.*;  

import java.io.IOException;


//Handle Exception Using try-catch block

class Demo
{
	void method() throws IOException
	{
		throw new IOException("error");
	}
}

public class Throws1 {

	public static void main(String[] args) {
		
		try
		{
			Demo d = new Demo();
			d.method();
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}
		System.out.println("rest");
	}
}

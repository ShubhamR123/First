package Throws;

import java.io.IOException;
//Declare Exception

//In case we declare the exception, if exception does not occur, 
//the code will be executed fine.

class Demo1
{
	void method()
	{
		System.out.println("hey");
	}
}

public class Throws2 {
public static void main(String[] args) throws IOException{   // declare exception
	
	Demo1 d = new Demo1();
	d.method();
	System.out.println("rest");
}
}

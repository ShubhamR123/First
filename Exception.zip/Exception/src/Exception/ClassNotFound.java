package Exception;

public class ClassNotFound {

	public static void main(String[] args) {
		
		try
		{
			Class.forName("com.Exception.FileNotFound1");
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		
	}
}

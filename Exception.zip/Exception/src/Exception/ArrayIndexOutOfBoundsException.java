package Exception;


//to handle unchecked exception.

public class ArrayIndexOutOfBoundsException {

	public static void main(String[] args) {
		

		try
		{
			int array[] = {2,3,5};

			System.out.println(array[3]); //may throw exception 
		}
		
		  // handling the array exception 	
		catch(Exception e)
		{
			System.out.println(e);
		}
        System.out.println("rest of the code");  

	}
}

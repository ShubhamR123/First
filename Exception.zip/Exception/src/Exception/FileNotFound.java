package Exception;


//to handle checked exception.

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Stream;

public class FileNotFound {

	public static void main(String[] args) throws IOException  {
		
//		try {
//			File file = new File("c class.txt");
//			
//			FileReader fr = new FileReader(file);
//		}
//		catch(FileNotFoundException e)
//		{
//			System.out.println("File does not exist");
//		}
		
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader("c class.txt")))
		{
			Stream<String> lines = bufferedReader.lines();
			lines.forEach(System.out::println);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
			
		}
		
	}

	
}

package Exception;

 class NullPointer {

	public static void main(String[] args) {
		
		try
		{
			String a = "dog";
			System.out.println(a.length());	  // show length
			
		String b = null;
		System.out.println(b.length());  
		
		}
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
	        System.out.println("rest");
	}
}

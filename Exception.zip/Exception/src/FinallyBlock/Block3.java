package FinallyBlock;


// When an exception occurs and is handled by the catch block

public class Block3 {

	public static void main(String[] args) {
		
         try
      {
	  System.out.println("Inside the try block");  

		int data = 30/0;
		System.out.println(data);
      }
         catch(ArithmeticException e)
         {
        	 System.out.println("Arithmetic "+e);
         }
         finally
         {
        	 System.out.println("finally block");
         }
         System.out.println("rest");

	}
}

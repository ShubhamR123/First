package FinallyBlock;


//When an exception occur but not handled by the catch block

public class Block2 {

	public static void main(String[] args) {
		
		try
		{
	        System.out.println("Inside the try block");  

			int data = 30/0;
			System.out.println(data);

		}                                   //its a arithmetic exception but i,m using a null pointer 
		catch(NullPointerException e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("finally block");
		}
		System.out.println("rest");
	}
}

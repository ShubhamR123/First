package FinallyBlock;


//When an exception does not occur

public class Block1 {

	public static void main(String[] args) {
		
		try
		{
			int data = 30/2;
			System.out.println(data);
		}
		catch(NullPointerException e)
		{
			System.out.println("nullPointer"+e);
		}
		finally
		{
			System.out.println("finally block");
		}
		System.out.println("rest");
	}
}

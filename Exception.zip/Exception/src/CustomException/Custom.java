package CustomException;


// class representing custom exception  
class age extends Exception
{
	public age (String str)
	{
		super(str);           // calling the constructor of parent Exception  

	}
}
public class Custom {

	static void validate (int age) throws age      // method to check the age  

	{
		if (age < 18)
		{
			// throw an object user defined exception
			throw new age ("person is not eligible for voting");
		}
		else
		{
			System.out.println("person is  eligible for voting");
		}
	}
	public static void main(String[] args) {
		
		try
		{
			validate(19);  //calling method
		}
		catch(age e)
		{
			System.out.println("caught the exception");
		}
		System.out.println("rest");
	}
}

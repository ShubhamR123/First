package ExceptionPropagation;

public class Throw1 {

	void show()
	{  
	    int data=50/0;  
	  }  
	  void display()
	  {  
	    show();  
	  }  
	  void print()
	  {  
	   try
	   {  
	    display();  
	   }
	   catch(Exception e)
	   {
		   System.out.println("exception handled");
	    }  
	  }  
	  public static void main(String args[])
	  {  
		  Throw1 obj=new Throw1();  
	   obj.print();  
	   System.out.println("normal flow...");  
	  }  

}
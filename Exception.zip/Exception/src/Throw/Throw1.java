package Throw;

//Throwing Unchecked Exception

public class Throw1 {

	
	public static void voting(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Person is not eligible for vote");
		}
		else
		{
			System.out.println("person is eligible for vote");
		}
	}
	
	public static void main(String[] args) {
		
		voting(19);   //person is eligible for vote


		voting(17); 
		
		System.out.println("rest");
	}
}

package Throw;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

//Throwing Checked Exception

public class Throw2 {

	public static void method() throws FileNotFoundException
	{
		FileReader file = new FileReader("c class.txt");
		BufferedReader files = new BufferedReader(file);
		
		throw new FileNotFoundException();
		
	}
	public static void main(String[] args) {
		
		try
		{
			method();
		}
		catch(FileNotFoundException e)
		{
             e.printStackTrace();	
         }
		System.out.println("rest");
	}
}

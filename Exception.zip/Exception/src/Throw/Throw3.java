package Throw;


//Throwing User-defined Exception


                                              //class represents user-defined exception  

class UserDefinedException extends Exception
{
	public UserDefinedException (String str)
	{
                                           // Calling constructor of parent Exception  

		super(str);
	}
}
public class Throw3 {

	public static void main(String[] args) {
		
		try
		{
                                            // throw an object of user defined exception  

			throw new UserDefinedException("user-defined");
		}
		catch(UserDefinedException e)
		{
			System.out.println(e);
		}
		System.out.println("rest");
	}
}

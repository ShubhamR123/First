package Api;

import java.util.Random;
import java.util.Stack;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Java_concurrency_Producer {

	private Stack<Integer> stack = new Stack<>();
	private final int capaity = 5;
	private Lock  lock = new ReentrantLock();    // lock is interface
	private Condition stackEmptyCondition = lock.newCondition();    // mentioned new condition  stackEmptyCondition
	private Condition stackFullCondition = lock.newCondition();
	
	public void pushTostack() throws InterruptedException {  //push(E element) method is used to push an element into the Stack
		
		try
		{
			lock.lock(); 
			while(stack.size() == capaity)  // thread has to check whether size of capacity
			{
				stackFullCondition.await(); // await method which belongs to the condition interface
			}
			
			Random random = new Random(); // we can generate random numbers
			
			int item = random.nextInt(1000); // generate 3 digits numbers
			stack.push(item);  //pushing into the stack
			
			System.out.println("Produced :::"+item);
			Thread.sleep(1000);
			stackEmptyCondition.signalAll(); // multiple consumers  and producers to signal all
		}
		
		finally {
			lock.unlock();  // lock.unlock() method calling the finally block
		}
	}
	
	public void popFromStack() throws InterruptedException
	{
		try
		{
			lock.lock();  // accure lock by calling the lock method
			while (stack.size() == 0)   // consumer has check stack and size then go through the await method
			{
				stackEmptyCondition.await();  
			}
			Integer item = stack.pop(); // pop remove data from the stack
			System.out.println("Consumed :::"+item);
			Thread.sleep(1000);  // 1 mili second
			stackFullCondition.signalAll();
		}
		finally {
			lock.unlock();
		}
	}
}

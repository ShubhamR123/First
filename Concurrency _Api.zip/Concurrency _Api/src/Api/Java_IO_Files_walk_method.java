
package Api;

import java.io.IOException;
import java.nio.file.DirectoryStream.Filter;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Java_IO_Files_walk_method {

	public static void main(String[] args) {
		
		Path start = Paths.get("/Users/apple/Documents/workspace-spring-tool-suite-4-4.15.3.RELEASE/Concurrency _Api");
		
		try (Stream<Path> walk = Files.walk(start, Integer.MAX_VALUE, FileVisitOption.FOLLOW_LINKS))
		{
			walk.forEach(System.out::println);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}

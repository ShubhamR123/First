package Api;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Stream;

public class Java_IO_BufferReader_Lines_Method {

	//File processing template
	// 1) open the file
	// 2) process the file (read / write )
	// 3) close the file
	
	// file input (reading from a file )
	
	public static void main(String[] args) throws IOException {
		
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader("c class.txt")))
		{
			Stream<String> lines = bufferedReader.lines();
			lines.forEach(System.out::println);
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
			
		}
		
	}
}

package Api;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Java_Concurrency_ClientTest {

	public static void main(String[] args) {
		
		ExecutorService executorService = null;
		try
		{
			executorService = Executors.newFixedThreadPool(2);
			final Java_concurrency_Producer java_concurrency_Producer = new Java_concurrency_Producer();
			
			Runnable produceTask = new Runnable() {   // create two runnable class
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while (true)
					{
						try
						{
							java_concurrency_Producer.pushTostack();
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
					}
				}
			};
		
			Runnable consumerTask = new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					while (true)
					{
						try
						{
							java_concurrency_Producer.popFromStack();
						}
						catch(InterruptedException e)
						{
							e.printStackTrace();
						}
					}
				}
			};
			executorService.submit(produceTask);
			executorService.submit(consumerTask);
	}
		catch (Exception e)
		{
			e.printStackTrace();
		}
}
}

package Oops_concept;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Functional_interface {

public static void main(String[] args) {
	
	
	
	//Functional Interface types ---- 4 types
	 
	 // 1) Predicate-- boolean result
	 
	 Predicate<String> checkLength = str -> str.length()>5;
	 
	 //checking if length of string >5 --- true -- else -- false
	 
	 System.out.println(checkLength.test("checklength")); //true
	 
	 System.out.println(checkLength.test("Hey"));// false

		System.out.println("................");

	 
	 // 2) Consumer-- modifies-- data--- no output
	 
	 class Demo
	 {
		 private String name;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	 }
	 
	 Demo p = new Demo();
	 Consumer<Demo> setName =t->t.setName("Hello World");
	 setName.accept(p);
	 System.out.println(p.getName());
		System.out.println("................");

	 
	 // 3)  Function both input and output
	 
	 Function<Integer, String> getInt =t->t*5 + " data multiple by 5 ";
	 System.out.println(getInt.apply(5));
	 
		System.out.println("................");

	 // 4) Supplier-- only output
	 
	 Supplier<Double> getrandomDouble=()-> Math.random();
	 System.out.println(getrandomDouble.get());
}
}

package Oops_concept;


class Calculate
{
	int num1;        //variables
	int num2;
	int result;
	
	public void Total()        // methods
	{
		result = num1 + num2 ;
	}
}
public class Class_and_Object {

	public static void main(String[] args) {
		
		Calculate cal = new Calculate();        // class name create object
		cal.num1 = 7;
		cal.num2 = 14;
		
		cal.Total();
		
		System.out.println(cal.result);
	}
}

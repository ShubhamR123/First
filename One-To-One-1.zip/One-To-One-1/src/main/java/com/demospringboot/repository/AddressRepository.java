package com.demospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demospringboot.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
}

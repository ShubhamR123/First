package com.demospringboot;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demospringboot.entity.Gender;
import com.demospringboot.entity.User;
import com.demospringboot.entity.UserProfile;
import com.demospringboot.repository.UserProfileRepository;
import com.demospringboot.repository.UserRepository;

@SpringBootApplication
public class SpringbootHibernateOneToOneMappingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHibernateOneToOneMappingApplication.class, args);
	}
     
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserProfileRepository userProfileRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		
		User user = new User();
		user.setName("Shubham");
		user.setEmail("shubhamrachelwar91@gmail.com");
		
		
		UserProfile userProfile = new UserProfile();
		userProfile.setAddress("Nagpur");
		userProfile.setBirthOfDate(LocalDate.of(1996, 03, 23));
		userProfile.setGender(Gender.MALE);
		userProfile.setPhoneNumber("9359722721");
		
		user.setUserProfile(userProfile);
		userProfile.setUser(user);
		
		userRepository.save(user);
		
	}

}

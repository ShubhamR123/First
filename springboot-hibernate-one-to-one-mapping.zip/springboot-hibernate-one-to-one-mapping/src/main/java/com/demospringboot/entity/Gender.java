package com.demospringboot.entity;

public enum Gender {
MALE , FEMALE
}

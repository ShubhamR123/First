package com.demospringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHibernateOneToOneMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}

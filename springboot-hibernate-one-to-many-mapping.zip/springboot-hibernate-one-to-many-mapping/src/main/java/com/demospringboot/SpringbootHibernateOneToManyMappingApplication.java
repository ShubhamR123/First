package com.demospringboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demospringboot.entity.Comment;
import com.demospringboot.entity.Post;
import com.demospringboot.entity.repository.PostRepository;

@SpringBootApplication
public class SpringbootHibernateOneToManyMappingApplication  implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHibernateOneToManyMappingApplication.class, args);
	}

	@Autowired
	private PostRepository postRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Post post = new Post("One to Many mapping using JPA and Hibernate" , "One to Many mapping using JPA and Hibernate");
		
		Comment comment1 = new Comment("Java");
		Comment comment2 = new Comment("C++");
		Comment comment3 = new Comment("C");
		
		post.getComments().add(comment1);
		post.getComments().add(comment2);
		post.getComments().add(comment3);

this.postRepository.save(post);
		
	}

}

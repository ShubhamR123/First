package com.corejava;



public class StaticBlock {
	static {
		System.out.println("block");
	}

public static void main(String[] args) {
	System.out.println("main");
}
}

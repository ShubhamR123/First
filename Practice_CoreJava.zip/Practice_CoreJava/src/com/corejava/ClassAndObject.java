package com.corejava;


class Student4
{
	int rollno = 1;
	String name ="abc";
	
}
public class ClassAndObject {
public static void main(String[] args) {
	
Student4 s1 = new Student4();
System.out.println(s1.rollno);
System.out.println(s1.name);


}

}

package com.corejava;

class Student5
{
	Student5()    // creating default constructor
	{
		System.out.println("Default Constructor");
	}
}
public class DefaultConstructor {
	
public static void main(String[] args) {
	
	 Student5 s1 = new Student5();  // calling a default Constructor

}	
}

package com.corejava;

public class FinallyBlock {

	public static void main(String[] args) {
		
		try
		{
			int a = 10 , b = 2, c;  // mentioned b = 0 so print ArithmeticException.and also print finally block
			
			c = a / b;
			System.out.println(c);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		finally {
			
			System.out.println("Finally");
		}
	}
}

package com.corejava;

class Student8
{
	static Student8 s = new Student8();
	
	private Student8()
	{
		System.out.println("Construct will invoke for only one object");
	}
	static Student8 getInstance()
	{
		return s;
		
	}
}
public class SingletonClass {
public static void main(String[] args) {
	
	Student8 s = Student8.getInstance();

	
}
}

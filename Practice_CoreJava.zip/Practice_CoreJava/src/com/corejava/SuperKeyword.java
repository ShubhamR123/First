package com.corejava;

class A2
{
	int i = 10;  // instance variable
}
class B2 extends A2
{
	int i = 20;             //result show using this keyword
	void show(int i)     // local variable  //print 30
	{
		System.out.println( i);
		System.out.println(this.i); //this refer to the current class instance variable //print 20
	
	 System.out.println(super.i);  // super refer to the parent class // class B parent class A  // print 10
	}
}
public class SuperKeyword {

	public static void main(String[] args) {
		
		B2 b = new B2();
		b.show(30);
		
	}
}

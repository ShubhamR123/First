package com.corejava;

import java.util.Scanner;

public class swap {
 public static void main(String[] args) {
	
	Scanner scanner = new Scanner(System.in);
	
	int x = scanner.nextInt();
	int y = scanner.nextInt();
	System.out.println("before swap"+x+" "+y);
	
	x = x+y;
	y = x-y;
	x = x-y;
	
	
	System.out.println("after swap"+x+" "+y);

 }
}

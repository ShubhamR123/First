package com.corejava;


class Student
{
	int rollno;       // instance variable
	String name;
static String college ="raisoni";    //static variable

Student(int r, String n)     // constructor
{
	rollno = r;
	name = n;
}

void Display()     // method to display the values
{
	System.out.println(rollno+" "+name+" "+college);   
}
}
public class StaticVariable {
	public static void main(String[] args) {
		
		Student s1 = new Student(1, "shubham");
		s1.Display();
	}

}

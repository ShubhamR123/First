package com.corejava;

class A{
	void show()
	{
		System.out.println("Hello");
	}
}
	class B extends A{
		void display()
		{
			System.out.println("Hey");
		}
	}

public class SingleInheritance {
public static void main(String[] args) {
	
	B b = new B();
	b.show();
	b.display();
	
}
}

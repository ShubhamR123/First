package com.corejava;

abstract class AbstractionExample // A method must always be declared in a abstract class, 
                                 // or we can say that if a class has an abstract method, 
                                 // it should be declared abstract as well.
{
	abstract void start();    //A method without body (no implementation) as abstract method.
	
	}
	class Car extends AbstractionExample //If a regular class extends an abstract class, then the class
	                                     //must have to implement all the abstract methods of abstract
	                                     //parent class it has to be declared abstract as well
	{
			void start()
		{
			System.out.println("Car start with Key");
		}
	}

	class Scooter extends AbstractionExample      //Abstract methods in an abstract class are meant to be 
	                                              //overridden in derived concrete classes otherwise compile time error will be thrown
	{
		void start()
		{
			System.out.println("Scooter start with Kick");

		}
		public static void main(String[] args) {
			
			//Abstraction a = new Abstraction();    //Abstract classes cannot be instantiated , means
			                                        // we can,t create an object of Abstract class.
			Car c = new Car();
			c.start();
			
			Scooter s = new Scooter();
			s.start();
		}
}

package com.corejava;

class Demo
{
	static int add(int a, int b)
	{
		return a + b;
	}
	
	static double add (double a , double b, double c)
	{
		return a + b + c;
	}
}
public class MethodOverloading {
	
public static void main(String[] args) {
	
	System.out.println(Demo.add(10, 42));
	System.out.println(Demo.add(3.3, 3.5, 20));
}
}

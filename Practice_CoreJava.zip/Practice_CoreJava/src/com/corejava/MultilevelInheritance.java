package com.corejava;

class Aa{
	void show()
	{
		System.out.println("Hello");
	}
}
	class Bb extends Aa{
		void display()
		{
			System.out.println("hey");
		}
	}
	class Cc extends Bb{
		void print()
		{
			System.out.println("hi");
		}
	}

class MultilevelInheritance {
	
public static void main(String[] args) {
	
	Cc obj = new Cc();
	obj.print();
     obj.display();
	obj.show();
}
}

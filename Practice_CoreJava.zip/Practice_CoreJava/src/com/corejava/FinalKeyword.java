package com.corejava;
class A7
{
	  void M1()        //final method cannot be override
	{
		System.out.println("Demo ");
	}
}

public class FinalKeyword extends A7{
	void M1()           //error final class can,t inheritance
	{
		System.out.println("Test");
	}

	public static void main(String[] args) {
		FinalKeyword m = new FinalKeyword();
		m.M1();
		
//		int i= 10;
//		i = i + 20;
//		System.out.println(i);
		
//		final int i = 10;
//		i = i + 20;  //The final local variable i cannot be assigned. 
//		System.out.println(i);
	}
}

package com.corejava;

class Plot{
	int RateOfInterest()
	{
		return 8;
	}
}

class House extends Plot{
	int RateOfInterest()
	{
		return 10;
	}
}
class Flats extends Plot{
	int RateOfInterest()
	{
		return 12;
	}
}
class banglow extends Plot{
	int RateOfInterest()
	{
		return 16;
	}
}
public class MethodOverriding {

	public static void main(String[] args) {
		
		House h = new House();
		Flats f = new Flats();
		banglow b = new banglow();
		
		System.out.println("House "+h.RateOfInterest());
		System.out.println("Flats "+f.RateOfInterest());
		System.out.println("banglow "+b.RateOfInterest());
	}
}

package com.corejava;

class A1{
	void show()
	{
		System.out.println("java");
	}
	
}
class B1 extends A1{
	void demo()
	{
		System.out.println("C++");
	}
}
class C1 extends A1{
	void test()
	{
		System.out.println("C#");
	}
}
public class HierarchicalInheritance {
public static void main(String[] args) {
	
	C1 c = new C1();
	c.show();
	c.test();
}
}

package com.corejava;

public class Variables {

static int A = 30;  // static variable

void Display()
{
	int B = 50;   // local variable
}
public static void main(String[] args) {
	
	int data = 60;  // Instance variable
	
	
	
}
}

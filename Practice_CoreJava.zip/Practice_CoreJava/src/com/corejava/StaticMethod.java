package com.corejava;


class Student1
{
	int rollno;   // instance variable
	String name;
	
	static String college = "raisoni";   // static variable
	
	static void change()    // static method to change the value of static variable
	{
		college = "ycc";
	}
	
	Student1(int r, String n)   //constructor
	{
		rollno = r;
		name = n;
	}
	
	void Display()     //method
	{
		System.out.println(rollno+" "+name+" "+college);
	}
}
public class StaticMethod {
public static void main(String[] args) {
	Student1.change();
	Student1 s1 = new Student1(1, "hyw");
	s1.Display();        //calling display method
}
}

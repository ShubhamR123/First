package com.corejava;

class Student6
{
	int rollno;
	String name;
	int age;
	
    //creating two arg constructor  

	Student6(int r, String n)
	{
		rollno = r;
		name = n;
	}
    //creating three arg constructor  

	Student6(int r, String n, int a)
	{
		rollno = r;
		name = n;
		age = a;
	}
	
	void display()
	{
		System.out.println(rollno+" "+name+" "+age);
	}
}
public class ConstructorOverloading {
 public static void main(String[] args) {
	
	 Student6 s1 = new Student6(1, "hey");
	 Student6 s2 = new Student6(2, "helo", 26);
	 
	 s1.display();
	 s2.display();
}
}

package com.corejava;

class Student7{
	
	int rollno;
	String name;
	
	Student7(int r, String n)
	
	{
		rollno = r;
		name = n;
	}
	
	Student7(Student7 s)
	{
		rollno = s.rollno;
		name = s.name;
	}
	
	void display()
	{
		System.out.println(rollno+ " "+name);
	}
}


public class CopyConstructor {
 public static void main(String[] args) {
	
	 Student7 s = new Student7(1, "mayur");
	 Student7 s1 = new Student7(s);
	 s.display();
	 s1.display();
}
}

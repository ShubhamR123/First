package com.demospringboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demospringboot.entity.Post;
import com.demospringboot.entity.Tag;
import com.demospringboot.repository.PostRepository;
import com.demospringboot.repository.TagRepository;

@SpringBootApplication
public class SpringbootHibernateManyToManyMappingApplication implements CommandLineRunner{

	
	@Autowired
	private PostRepository postRepository;
	
	@Autowired
	private TagRepository tagRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootHibernateManyToManyMappingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Post post = new Post("Hibernate many to many example with spring boot",
				"Hibernate many to many example with spring boot",
				"Hibernate many to many example with spring boot");
		
		Tag springBoot = new Tag("Spring Boot");
		Tag hibernate = new Tag ("Hibernate");
		
		//add tag references tag
		
		post.getTags().add(springBoot);
		post.getTags().add(hibernate);
		
		//add post references tag
		
		springBoot.getPosts().add(post);
		hibernate.getPosts().add(post);
		
		this.postRepository.save(post);
	}

}

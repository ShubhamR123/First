package com.demospringboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demospringboot.entity.Book;
import com.demospringboot.service.BookService;

@RestController
@RequestMapping("/api/book")
@CrossOrigin
public class BookController {
    @Autowired
    private BookService bookService;

    @PostMapping("")
    public ResponseEntity<Book> addABook(@RequestBody Book book) {
        return new ResponseEntity<Book>(bookService.saveOrUpdateABook(book), HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public Iterable<Book> getAllBookings(){
        return bookService.findAll();
    }

    @GetMapping("/{bookId}")
    public ResponseEntity<Book> getBookingById(@PathVariable Long bookId) {
        return new ResponseEntity<Book>(bookService.findBookById(bookId), HttpStatus.OK);
    }
}

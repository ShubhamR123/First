package com.demospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demospringboot.entity.Role;

public interface RoleRepo extends JpaRepository<Role, Integer>{

}

package com.demospringboot.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "users_contact")
public class UsersContact {

    public UsersContact(int phoneNo, Users users) {
		super();
		this.phoneNo = phoneNo;
		this.users = users;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;
    private int phoneNo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "user_id", referencedColumnName = "user_id")
    private Users users;

    public UsersContact() {
    }

    public Users getUsers() {
        return users;
    }

    public UsersContact setUsers(Users users) {
        this.users = users;
        return this;
    }

    public int getId() {
        return id;
    }

    public UsersContact setId(int id) {
        this.id = id;
        return this;
    }

    public int getPhoneNo() {
        return phoneNo;
    }

    public UsersContact setPhoneNo(int phoneNo) {
        this.phoneNo = phoneNo;
        return this;
    }
}
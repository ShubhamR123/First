package com.demospringboot.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
@Entity
@Table(name = "users")
public class Users {

    @Override
	public String toString() {
		return "Users [id=" + id + ", name=" + name + ", salary=" + salary + ", teamName=" + teamName + "]";
	}

	public Users(String name, int salary, String teamName) {
		super();
		this.name = name;
		this.salary = salary;
		this.teamName = teamName;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "user_id")
    private int id;
	
    @Column(name = "name")
    private String name;
    
    @Column(name = "salary")
    private int salary;
    
    @Column(name= "team_name")
    private String teamName;

    public Users() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
        //return this;
    }

    public String getName() {
        return name;
    }

    public Users setName(String name) {
        this.name = name;
        return this;
    }

    public int getSalary() {
        return salary;
    }

    public Users setSalary(int salary) {
        this.salary = salary;
        return this;
    }

    public String getTeamName() {
        return teamName;
    }

    public Users setTeamName(String teamName) {
        this.teamName = teamName;
        return this;
    }
}
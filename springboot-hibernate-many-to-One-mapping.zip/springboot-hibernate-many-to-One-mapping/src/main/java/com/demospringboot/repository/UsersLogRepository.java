package com.demospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demospringboot.entity.UsersLog;

public interface UsersLogRepository extends JpaRepository<UsersLog, Integer> {
}

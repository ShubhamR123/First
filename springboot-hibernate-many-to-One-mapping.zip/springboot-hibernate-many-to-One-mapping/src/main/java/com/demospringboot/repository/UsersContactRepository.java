package com.demospringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demospringboot.entity.UsersContact;

public interface UsersContactRepository extends JpaRepository<UsersContact, Integer> {
}
